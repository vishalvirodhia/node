**To delete a health check**

The following ``delete-health-check`` command deletes the health check with a ``health-check-id`` of ``e75b48d9-547a-4c3d-88a5-ae4002397608``::

  aws route53 delete-health-check --health-check-id e75b48d9-547a-4c3d-88a5-ae4002397608
